<?php
session_start();
?>
<html>
<head>
<title>issue page</title>
</head>
<body style="background:url(title1.jpg) no-repeat; background-size:100%">
<div align="center">
<form action="issue1.php" method="POST">
<h3 style="color:orange">enter the book title:<input type="text" name="title"/><br>
<input type="submit" name="submit" value="submit"/></h3>
</form> 
</div>
</body>
</html>
