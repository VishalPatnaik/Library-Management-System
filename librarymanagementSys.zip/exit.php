<?php
 echo '<script> window.setTimeout("window.close()",10);</script>';
 ?>
<html>
<div align="center">
<body style="background:url(va.jpg) no-repeat; background-size:100%" align="center">
</body>
</div>
</html>