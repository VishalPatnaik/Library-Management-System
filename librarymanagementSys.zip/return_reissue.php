<html>
<head>
<title>Return/Reissue</title>
</head>
<body style="background:url(reissue.jpg) no-repeat; background-size:100%">
<div align="center">
<h1><b>RETURN OR REISSUE THE BOOK</b><h1>
<form>
<div align="center" >

<input type="button" onClick="parent.location='reissue.php'" value="reissue">
<input type="button" onClick="parent.location='return.php'" value="return">
</div>
<form>
</div>
</body>
</html>