<?php
 session_start(); 
?>
<html>
<head>
<title>return</title>
</head>
<body style="background:url(re.jpg) no-repeat; background-size:100%" align="center">
<div align="center">
<form action="reissue1.php" method="POST"><h3>
enter the bookid:<input type="text" name="bid" placeholder="book id" required></h3>
<input type="submit" name="submit" value="submit"/>
</form>
</div>
</body>
</html>